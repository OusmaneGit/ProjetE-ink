DFRobot SD_SPI library is from Arduino official library (https://github.com/arduino-libraries/SD) <br>
We have amended it to make it compatible with ESP8266, ESP32,AVR(other platforms are not tested). <br>
Its usage method is the same as Arduino libraries/SD. <br>
For any questions, advice or cool ideas to share, please visit the DFRobot Forum(https://www.dfrobot.com/forum/). <br>
